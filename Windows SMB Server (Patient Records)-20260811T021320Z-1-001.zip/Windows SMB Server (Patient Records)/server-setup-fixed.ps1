# Operation Code Blue - Windows Server 2022 lab bootstrap
# Run in an elevated PowerShell window.

$ErrorActionPreference = "Stop"

$LabUser = "ncarter"
$LabPasswordPlain = "NurseLab2026!"
$Root = "C:\HospitalLab\PatientRecords"
$Demo = Join-Path $Root "RansomwareDemo"
$ShareName = "PatientRecords"
$ServerName = $env:COMPUTERNAME
$QualifiedUser = "$ServerName\$LabUser"

Write-Host "[1/7] Creating fictional local account..."
$SecurePassword = ConvertTo-SecureString $LabPasswordPlain -AsPlainText -Force
if (-not (Get-LocalUser -Name $LabUser -ErrorAction SilentlyContinue)) {
    New-LocalUser -Name $LabUser -Password $SecurePassword `
        -FullName "Nina Carter (Fictional Nurse)" `
        -Description "Operation Code Blue training account" `
        -PasswordNeverExpires
}
if (-not (Get-LocalGroupMember -Group "Users" -Member $LabUser -ErrorAction SilentlyContinue)) {
    Add-LocalGroupMember -Group "Users" -Member $LabUser
}

Write-Host "[2/7] Creating fictional patient folders..."
$Folders = @(
    "$Root\Radiology\PT-1001_Avery_Stone",
    "$Root\Cardiology\PT-1002_Jordan_Reed",
    "$Root\Oncology\PT-1003_Riley_West",
    $Demo
)
$Folders | ForEach-Object { New-Item -ItemType Directory -Path $_ -Force | Out-Null }

Write-Host "[3/7] Writing fictional records..."
@"
FICTIONAL TRAINING RECORD
Patient ID: PT-1001
Name: Avery Stone
Department: Radiology
Result: Simulated imaging report for an authorized cybersecurity lab.
No real patient information is contained in this file.
"@ | Set-Content "$Root\Radiology\PT-1001_Avery_Stone\Imaging_Report.txt"

@"
FICTIONAL TRAINING RECORD
Patient ID: PT-1002
Name: Jordan Reed
Department: Cardiology
Result: Simulated cardiology report for an authorized cybersecurity lab.
No real patient information is contained in this file.
"@ | Set-Content "$Root\Cardiology\PT-1002_Jordan_Reed\Cardiology_Report.txt"

@"
FICTIONAL TRAINING RECORD
Patient ID: PT-1003
Name: Riley West
Department: Oncology
Result: Simulated oncology report for an authorized cybersecurity lab.
No real patient information is contained in this file.
"@ | Set-Content "$Root\Oncology\PT-1003_Riley_West\Oncology_Report.txt"

1..5 | ForEach-Object {
    "FICTIONAL TRAINING RECORD $_ - disposable ransomware-impact demo file." |
        Set-Content (Join-Path $Demo ("Demo_Record_{0}.txt" -f $_))
}

Write-Host "[4/7] Applying NTFS permissions..."
# Remove inherited permissions so membership in BUILTIN\Users cannot provide
# unintended write access to the patient-record folders.
icacls $Root /inheritance:r /T /C | Out-Null

# Remove broad explicit Allow entries if this script is being rerun over an
# older lab build. Missing entries are harmless and are ignored by icacls.
icacls $Root /remove:g `
    "BUILTIN\Users" `
    "NT AUTHORITY\Authenticated Users" `
    "Everyone" /T /C | Out-Null

# Establish the intended permission baseline throughout the tree:
#   SYSTEM and Administrators = Full Control
#   fictional nurse account   = Read and Execute only
icacls $Root /grant:r `
    "NT AUTHORITY\SYSTEM:(OI)(CI)(F)" `
    "BUILTIN\Administrators:(OI)(CI)(F)" `
    "${QualifiedUser}:(OI)(CI)(RX)" /T /C | Out-Null

# Override the nurse account only in the disposable demonstration folder.
icacls $Demo /grant:r "${QualifiedUser}:(OI)(CI)(M)" /T /C | Out-Null

Write-Host "[5/7] Creating SMB share..."
if (Get-SmbShare -Name $ShareName -ErrorAction SilentlyContinue) {
    Remove-SmbShare -Name $ShareName -Force
}
New-SmbShare -Name $ShareName -Path $Root `
    -ReadAccess $QualifiedUser `
    -FullAccess "BUILTIN\Administrators" | Out-Null

# Share-level Change is required for the dedicated demo folder.
Grant-SmbShareAccess -Name $ShareName -AccountName $QualifiedUser `
    -AccessRight Change -Force | Out-Null

Write-Host "[6/7] Enabling Windows file-sharing firewall rules..."
Get-NetFirewallRule -DisplayGroup "File and Printer Sharing" -ErrorAction SilentlyContinue |
    Where-Object { $_.Profile -match "Private" } |
    Enable-NetFirewallRule

Write-Host "[7/7] Displaying verification information..."
Write-Host ""
Write-Host "SERVER READY"
Write-Host "Computer name: $ServerName"
Write-Host "IPv4 addresses:"
Get-NetIPAddress -AddressFamily IPv4 |
    Where-Object { $_.IPAddress -notlike "127.*" -and $_.PrefixOrigin -ne "WellKnown" } |
    Select-Object InterfaceAlias,IPAddress,PrefixLength |
    Format-Table -AutoSize
Write-Host "SMB share: \\$ServerName\$ShareName"
Write-Host "Lab user: $QualifiedUser"
Write-Host "Lab password: $LabPasswordPlain"
Write-Host "Only C:\HospitalLab\PatientRecords\RansomwareDemo is writable by the lab user."
